--
-- PostgreSQL database dump
--

\restrict XImyldU6IFyJG3cLU7fMAQNCKy6N897D2Z2yD6R1lnsvMUjmbOyXl349ntbTZyh

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ComplianceStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."ComplianceStatus" AS ENUM (
    'PENDING',
    'REJECTED',
    'APPROVED'
);


ALTER TYPE public."ComplianceStatus" OWNER TO caenhebo;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."DocumentType" AS ENUM (
    'ENERGY_CERTIFICATE',
    'MUNICIPAL_LICENSE',
    'PREDIAL_REGISTRATION',
    'CADERNETA_PREDIAL_URBANA',
    'COMPLIANCE_DECLARATION',
    'REPRESENTATION_DOCUMENT',
    'MEDIATION_AGREEMENT',
    'PURCHASE_AGREEMENT',
    'PAYMENT_PROOF',
    'NOTARIZED_DOCUMENT',
    'TITLE_DEED',
    'CERTIFICATE',
    'PHOTO',
    'FLOOR_PLAN',
    'OTHER',
    'USAGE_LICENSE',
    'LAND_REGISTRY',
    'TAX_REGISTER',
    'OWNER_AUTHORIZATION',
    'CONTRACT',
    'PROOF_OF_PAYMENT',
    'LEGAL_DOCUMENT'
);


ALTER TYPE public."DocumentType" OWNER TO caenhebo;

--
-- Name: KycStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."KycStatus" AS ENUM (
    'PENDING',
    'INITIATED',
    'PASSED',
    'REJECTED',
    'EXPIRED'
);


ALTER TYPE public."KycStatus" OWNER TO caenhebo;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."NotificationType" AS ENUM (
    'NEW_OFFER',
    'OFFER_ACCEPTED',
    'OFFER_REJECTED',
    'COUNTER_OFFER',
    'PROPERTY_APPROVED',
    'PROPERTY_REJECTED',
    'PROPERTY_INTEREST',
    'DOCUMENT_UPLOADED',
    'TRANSACTION_STATUS_CHANGE',
    'KYC_STATUS_CHANGE',
    'INTERVIEW_SCHEDULED'
);


ALTER TYPE public."NotificationType" OWNER TO caenhebo;

--
-- Name: PaymentPreference; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."PaymentPreference" AS ENUM (
    'CRYPTO',
    'FIAT',
    'HYBRID'
);


ALTER TYPE public."PaymentPreference" OWNER TO caenhebo;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."PaymentStatus" OWNER TO caenhebo;

--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'OFFER',
    'NEGOTIATION',
    'AGREEMENT',
    'KYC2_VERIFICATION',
    'FUND_PROTECTION',
    'CLOSING',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."TransactionStatus" OWNER TO caenhebo;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."UserRole" AS ENUM (
    'BUYER',
    'SELLER',
    'ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO caenhebo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO caenhebo;

--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.bank_accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    "accountHolderName" text NOT NULL,
    "bankName" text NOT NULL,
    iban text NOT NULL,
    "swiftCode" text,
    "bankAddress" text,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "accountType" text,
    verified boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_accounts OWNER TO caenhebo;

--
-- Name: counter_offers; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.counter_offers (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    price numeric(65,30) NOT NULL,
    message text,
    terms text,
    "fromBuyer" boolean NOT NULL,
    accepted boolean DEFAULT false NOT NULL,
    rejected boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.counter_offers OWNER TO caenhebo;

--
-- Name: digital_ibans; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.digital_ibans (
    id text NOT NULL,
    "userId" text NOT NULL,
    iban text NOT NULL,
    "bankName" text,
    "accountNumber" text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.digital_ibans OWNER TO caenhebo;

--
-- Name: document_access; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.document_access (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "buyerId" text NOT NULL,
    "grantedBy" text NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    revoked boolean DEFAULT false NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    message text
);


ALTER TABLE public.document_access OWNER TO caenhebo;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "userId" text,
    "transactionId" text,
    "propertyId" text,
    type public."DocumentType" NOT NULL,
    filename text NOT NULL,
    "originalName" text,
    url text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    title text,
    description text,
    verified boolean DEFAULT false NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    signed boolean DEFAULT false NOT NULL,
    "signedAt" timestamp(3) without time zone,
    "signedBy" text,
    signature text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.documents OWNER TO caenhebo;

--
-- Name: escrow_details; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.escrow_details (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "escrowAccountId" text,
    "escrowProvider" text,
    "totalAmount" numeric(65,30) NOT NULL,
    "initialDeposit" numeric(65,30),
    "finalPayment" numeric(65,30),
    "releaseConditions" text,
    "fundsReceived" boolean DEFAULT false NOT NULL,
    "fundsReleased" boolean DEFAULT false NOT NULL,
    "fundingDate" timestamp(3) without time zone,
    "releaseDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.escrow_details OWNER TO caenhebo;

--
-- Name: escrow_steps; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.escrow_steps (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "stepNumber" integer NOT NULL,
    description text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    amount numeric(65,30),
    currency text,
    "adminApproved" boolean DEFAULT false NOT NULL,
    "adminNotes" text,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.escrow_steps OWNER TO caenhebo;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.interviews (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    duration integer DEFAULT 60 NOT NULL,
    notes text,
    completed boolean DEFAULT false NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    "conductedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.interviews OWNER TO caenhebo;

--
-- Name: legal_templates; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.legal_templates (
    id text NOT NULL,
    name text NOT NULL,
    type public."DocumentType" NOT NULL,
    content text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.legal_templates OWNER TO caenhebo;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    data jsonb,
    read boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    "transactionId" text,
    "propertyId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO caenhebo;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    type public."PaymentPreference" NOT NULL,
    amount numeric(65,30) NOT NULL,
    currency text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "walletAddress" text,
    "txHash" text,
    "bankDetails" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO caenhebo;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    bio text,
    avatar text,
    "companyName" text,
    "taxId" text,
    "dateOfBirth" timestamp(3) without time zone,
    address text,
    "addressLine2" text,
    city text,
    "postalCode" text,
    country text,
    "termsAcceptedAt" timestamp(3) without time zone,
    "privacyAcceptedAt" timestamp(3) without time zone,
    "amlAcceptedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.profiles OWNER TO caenhebo;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.properties (
    id text NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    description text,
    address text NOT NULL,
    city text NOT NULL,
    state text,
    "postalCode" text NOT NULL,
    country text DEFAULT 'Portugal'::text NOT NULL,
    price numeric(65,30) NOT NULL,
    area double precision,
    bedrooms integer,
    bathrooms integer,
    "sellerId" text NOT NULL,
    "complianceStatus" public."ComplianceStatus" DEFAULT 'PENDING'::public."ComplianceStatus" NOT NULL,
    "complianceNotes" text,
    "valuationPrice" numeric(65,30),
    "interviewDate" timestamp(3) without time zone,
    "interviewStatus" text DEFAULT 'NOT_SCHEDULED'::text NOT NULL,
    "interviewNotes" text,
    "finalApprovalStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.properties OWNER TO caenhebo;

--
-- Name: property_audits; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.property_audits (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "adminId" text NOT NULL,
    notes text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.property_audits OWNER TO caenhebo;

--
-- Name: property_interests; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.property_interests (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "buyerId" text NOT NULL,
    "interestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    message text
);


ALTER TABLE public.property_interests OWNER TO caenhebo;

--
-- Name: transaction_status_history; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.transaction_status_history (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "fromStatus" public."TransactionStatus",
    "toStatus" public."TransactionStatus" NOT NULL,
    "changedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transaction_status_history OWNER TO caenhebo;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    "buyerId" text NOT NULL,
    "sellerId" text NOT NULL,
    "propertyId" text NOT NULL,
    status public."TransactionStatus" DEFAULT 'OFFER'::public."TransactionStatus" NOT NULL,
    "offerPrice" numeric(65,30) NOT NULL,
    "agreedPrice" numeric(65,30),
    "initialPayment" numeric(65,30),
    "paymentMethod" public."PaymentPreference" DEFAULT 'FIAT'::public."PaymentPreference" NOT NULL,
    "cryptoPercentage" integer,
    "fiatPercentage" integer,
    "offerMessage" text,
    "offerTerms" text,
    "proposalDate" timestamp(3) without time zone,
    "acceptanceDate" timestamp(3) without time zone,
    "escrowDate" timestamp(3) without time zone,
    "completionDate" timestamp(3) without time zone,
    "deadlineDate" timestamp(3) without time zone,
    "buyerHasRep" boolean DEFAULT false NOT NULL,
    "sellerHasRep" boolean DEFAULT false NOT NULL,
    "mediationSigned" boolean DEFAULT false NOT NULL,
    "purchaseAgreementSigned" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "buyerSignedPromissory" boolean DEFAULT false,
    "buyerSignedPromissoryAt" timestamp(3) without time zone,
    "purchaseAgreementSignedAt" timestamp(3) without time zone,
    "sellerSignedPromissory" boolean DEFAULT false,
    "sellerSignedPromissoryAt" timestamp(3) without time zone,
    "buyerKyc2Verified" boolean DEFAULT false NOT NULL,
    "buyerKyc2VerifiedAt" timestamp(3) without time zone,
    "sellerKyc2Verified" boolean DEFAULT false NOT NULL,
    "sellerKyc2VerifiedAt" timestamp(3) without time zone,
    "kyc2StartedAt" timestamp(3) without time zone,
    "fundProtectionDate" timestamp(3) without time zone
);


ALTER TABLE public.transactions OWNER TO caenhebo;

--
-- Name: users; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    role public."UserRole" DEFAULT 'BUYER'::public."UserRole" NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    "phoneNumber" text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "dateOfBirth" timestamp(3) without time zone,
    "addressLine1" text,
    city text,
    state text,
    "postalCode" text,
    country text,
    "paymentPreference" public."PaymentPreference" DEFAULT 'FIAT'::public."PaymentPreference" NOT NULL,
    "strigaUserId" text,
    "kycStatus" public."KycStatus" DEFAULT 'PENDING'::public."KycStatus" NOT NULL,
    "kycSessionId" text,
    "kyc2Status" public."KycStatus" DEFAULT 'PENDING'::public."KycStatus" NOT NULL,
    "kyc2SessionId" text,
    "kyc2CompletedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO caenhebo;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.wallets (
    id text NOT NULL,
    "userId" text NOT NULL,
    "strigaWalletId" text NOT NULL,
    currency text NOT NULL,
    address text,
    "qrCode" text,
    balance numeric(65,30) DEFAULT 0 NOT NULL,
    "lastSyncAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.wallets OWNER TO caenhebo;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    "eventType" text NOT NULL,
    source text NOT NULL,
    "eventId" text,
    payload jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_events OWNER TO caenhebo;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
6d481ae6-02c9-42a8-93bd-7d6a7afce5a8	b188e54574bbe84a5d414abcf09c08e9b5df151f1e237eb226400208e617d003	\N	20250109_add_promissory_fields	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250109_add_promissory_fields\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "transactions" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"transactions\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(433), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-09-19 10:35:50.876306+00	2025-09-19 10:35:36.354925+00	0
36e96d38-ec5f-4a35-81a6-301280c2624b	b188e54574bbe84a5d414abcf09c08e9b5df151f1e237eb226400208e617d003	2025-09-19 10:35:50.877154+00	20250109_add_promissory_fields		\N	2025-09-19 10:35:50.877154+00	0
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.bank_accounts (id, "userId", "accountHolderName", "bankName", iban, "swiftCode", "bankAddress", currency, "accountType", verified, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: counter_offers; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.counter_offers (id, "transactionId", price, message, terms, "fromBuyer", accepted, rejected, "createdAt") FROM stdin;
cmfqt7ftm0007h2r1bo1lim0h	cmfqt4sef0001h2r1ph4j43vn	262000.000000000000000000000000000000	\N	\N	f	f	f	2025-09-19 12:22:01.691
\.


--
-- Data for Name: digital_ibans; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.digital_ibans (id, "userId", iban, "bankName", "accountNumber", active, "createdAt", "updatedAt") FROM stdin;
cmfqq7bn10001h2vdtnhcdvvx	cmfqptx630002h26lmvzj0tvd	PT50003506090000a75d55b5	Striga Bank (Test)	f7a75d55b5	t	2025-09-19 10:57:57.422	2025-09-19 10:57:57.422
cmfqqow9a0005h2vdmuj0fn94	cmfqptx660003h26llurbau9n	PT500035060900000987fa37	Striga Bank (Test)	eb0987fa37	t	2025-09-19 11:11:37.295	2025-09-19 11:11:37.295
\.


--
-- Data for Name: document_access; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.document_access (id, "propertyId", "buyerId", "grantedBy", "grantedAt", "expiresAt", revoked, "revokedAt", message) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.documents (id, "userId", "transactionId", "propertyId", type, filename, "originalName", url, "mimeType", size, title, description, verified, "uploadedAt", signed, "signedAt", "signedBy", signature, "createdAt", "updatedAt") FROM stdin;
cmfqs704x0001h20bpzp8jw5w	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	COMPLIANCE_DECLARATION	vLcou9HeayzIxN8KQbin9_1758282821743.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/vLcou9HeayzIxN8KQbin9_1758282821743.pdf	application/pdf	14804	\N	\N	f	2025-09-19 11:53:41.746	f	\N	\N	\N	2025-09-19 11:53:41.746	2025-09-19 11:53:41.746
cmfqs7ahp0003h20blz5j9za2	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	ENERGY_CERTIFICATE	cleyzj2kEINlKNU4rPZAF_1758282835164.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/cleyzj2kEINlKNU4rPZAF_1758282835164.pdf	application/pdf	14804	\N	\N	f	2025-09-19 11:53:55.166	f	\N	\N	\N	2025-09-19 11:53:55.166	2025-09-19 11:53:55.166
cmfqshv6t0001h2s89cianvdl	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	MUNICIPAL_LICENSE	46P0cvHgeESPEdz4dpOmQ_1758283328548.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/46P0cvHgeESPEdz4dpOmQ_1758283328548.pdf	application/pdf	14804	\N	\N	f	2025-09-19 12:02:08.55	f	\N	\N	\N	2025-09-19 12:02:08.55	2025-09-19 12:02:08.55
cmfqsi18c0003h2s82vfepz51	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	PREDIAL_REGISTRATION	pNEjJSSCMVfsxDet1bRiU_1758283336379.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/pNEjJSSCMVfsxDet1bRiU_1758283336379.pdf	application/pdf	14804	\N	\N	f	2025-09-19 12:02:16.38	f	\N	\N	\N	2025-09-19 12:02:16.38	2025-09-19 12:02:16.38
cmfqsi9210005h2s8rhtgto1e	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	CADERNETA_PREDIAL_URBANA	CqeW8ZI-eGxoXJ6AnG5fH_1758283346520.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/CqeW8ZI-eGxoXJ6AnG5fH_1758283346520.pdf	application/pdf	14804	\N	\N	f	2025-09-19 12:02:26.521	f	\N	\N	\N	2025-09-19 12:02:26.521	2025-09-19 12:02:26.521
cmfqsif2o0007h2s8pl40jmny	cmfqptx660003h26llurbau9n	\N	cmfqrfvpi0001h27y5vwyur33	OWNER_AUTHORIZATION	9dDr9mWL6SaxTfymkWjOy_1758283354318.pdf	test.pdf	/uploads/properties/cmfqrfvpi0001h27y5vwyur33/9dDr9mWL6SaxTfymkWjOy_1758283354318.pdf	application/pdf	14804	\N	\N	f	2025-09-19 12:02:34.32	f	\N	\N	\N	2025-09-19 12:02:34.32	2025-09-19 12:02:34.32
cmfqv7qv40001h2wdpdqg1quu	cmfqptx630002h26lmvzj0tvd	cmfqt4sef0001h2r1ph4j43vn	\N	REPRESENTATION_DOCUMENT	aeWpL4kyEaNdWVmG6RWQF_1758287895231.pdf	test.pdf	/uploads/transactions/cmfqt4sef0001h2r1ph4j43vn/aeWpL4kyEaNdWVmG6RWQF_1758287895231.pdf	application/pdf	14804	\N	\N	f	2025-09-19 13:18:15.232	f	\N	\N	\N	2025-09-19 13:18:15.232	2025-09-19 13:18:15.232
\.


--
-- Data for Name: escrow_details; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.escrow_details (id, "transactionId", "escrowAccountId", "escrowProvider", "totalAmount", "initialDeposit", "finalPayment", "releaseConditions", "fundsReceived", "fundsReleased", "fundingDate", "releaseDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: escrow_steps; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.escrow_steps (id, "transactionId", "stepNumber", description, status, amount, currency, "adminApproved", "adminNotes", "approvedBy", "approvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.interviews (id, "propertyId", "scheduledAt", duration, notes, completed, approved, "conductedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: legal_templates; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.legal_templates (id, name, type, content, version, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.notifications (id, "userId", type, title, message, data, read, "readAt", "transactionId", "propertyId", "createdAt", "updatedAt") FROM stdin;
cmfqq7bn40003h2vd13tg6tif	cmfqptx630002h26lmvzj0tvd	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 10:57:57.424	2025-09-19 10:57:57.424
cmfqqow9c0007h2vddnywnbxr	cmfqptx660003h26llurbau9n	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 11:11:37.297	2025-09-19 11:11:37.297
cmfqsjhg60009h2s8qi799w3s	cmfqptx660003h26llurbau9n	PROPERTY_APPROVED	Property Approved	Your property "3 bedroom house" has been approved and is now live! Property code: CAE-2025-0001	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": 0, "title": "3 bedroom house", "address": ""}}	f	\N	\N	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:03:24.054	2025-09-19 12:03:24.054
cmfqt4sew0005h2r1beny9zv3	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €250,000 on 3 bedroom house	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": "3520000", "title": "3 bedroom house", "address": "fdasfddf"}, "transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "OFFER", "offerPrice": 250000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:19:58.041	2025-09-19 12:19:58.041
cmfqt7ftt000bh2r1uyg10vu4	cmfqptx630002h26lmvzj0tvd	COUNTER_OFFER	Counter Offer Received	Test Seller made a counter-offer of €262,000 for 3 bedroom house	{"other": {"fromBuyer": false}, "transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "NEGOTIATION", "offerPrice": 262000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:22:01.697	2025-09-19 12:22:01.697
cmfqt7y17000fh2r19dheckjt	cmfqptx660003h26llurbau9n	OFFER_ACCEPTED	Offer Accepted!	Test Buyer accepted your offer of €262,000 for 3 bedroom house	{"transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "AGREEMENT", "offerPrice": 262000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:22:25.291	2025-09-19 12:22:25.291
cmfqv7qv70003h2wd1wdw9mj1	cmfqptx660003h26llurbau9n	DOCUMENT_UPLOADED	New Documents Uploaded	buyer@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 13:18:15.235	2025-09-19 13:18:15.235
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.payments (id, "transactionId", type, amount, currency, status, "walletAddress", "txHash", "bankDetails", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.profiles (id, "userId", bio, avatar, "companyName", "taxId", "dateOfBirth", address, "addressLine2", city, "postalCode", country, "termsAcceptedAt", "privacyAcceptedAt", "amlAcceptedAt", "createdAt", "updatedAt") FROM stdin;
cmfqptx350001h26l7ntekibb	cmfqptx350000h26l748hs4s0	Platform Administrator	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-19 10:47:32.033	2025-09-19 10:47:32.033
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.properties (id, code, title, description, address, city, state, "postalCode", country, price, area, bedrooms, bathrooms, "sellerId", "complianceStatus", "complianceNotes", "valuationPrice", "interviewDate", "interviewStatus", "interviewNotes", "finalApprovalStatus", "createdAt", "updatedAt") FROM stdin;
cmfqrfvpi0001h27y5vwyur33	CAE-2025-0001	3 bedroom house	my house	fdasfddf	lisbon	lisbon	10000	Portugal	3520000.000000000000000000000000000000	25	3	2	cmfqptx660003h26llurbau9n	APPROVED	\N	\N	2026-05-22 08:00:00	COMPLETED	great inverview	APPROVED	2025-09-19 11:32:36.295	2025-09-19 12:03:53.505
\.


--
-- Data for Name: property_audits; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.property_audits (id, "propertyId", "adminId", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: property_interests; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.property_interests (id, "propertyId", "buyerId", "interestedAt", message) FROM stdin;
cmfqsl142000bh2s8ub3np9mz	cmfqrfvpi0001h27y5vwyur33	cmfqptx630002h26lmvzj0tvd	2025-09-19 12:04:36.195	\N
\.


--
-- Data for Name: transaction_status_history; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.transaction_status_history (id, "transactionId", "fromStatus", "toStatus", "changedBy", notes, "createdAt") FROM stdin;
cmfqt4sei0003h2r13mxqf48p	cmfqt4sef0001h2r1ph4j43vn	\N	OFFER	cmfqptx630002h26lmvzj0tvd	Initial offer created	2025-09-19 12:19:58.027
cmfqt7ftr0009h2r1b2l0tovt	cmfqt4sef0001h2r1ph4j43vn	OFFER	NEGOTIATION	cmfqptx660003h26llurbau9n	Seller made counter offer	2025-09-19 12:22:01.696
cmfqt7y16000dh2r1ir8b1iio	cmfqt4sef0001h2r1ph4j43vn	NEGOTIATION	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Buyer accepted the counter-offer	2025-09-19 12:22:25.29
cmfqt8krp000hh2r1k3xr3z3q	cmfqt4sef0001h2r1ph4j43vn	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Buyer signed the Promissory Purchase & Sale Agreement	2025-09-19 12:22:54.758
cmfqtgs3u0001h29adf1rl9ct	cmfqt4sef0001h2r1ph4j43vn	AGREEMENT	AGREEMENT	cmfqptx660003h26llurbau9n	Seller signed the Promissory Purchase & Sale Agreement	2025-09-19 12:29:17.514
cmfqtgs3w0003h29ajwsuaep3	cmfqt4sef0001h2r1ph4j43vn	AGREEMENT	AGREEMENT	cmfqptx660003h26llurbau9n	Both parties have signed the Promissory Purchase & Sale Agreement - Agreement is now fully executed	2025-09-19 12:29:17.516
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.transactions (id, "buyerId", "sellerId", "propertyId", status, "offerPrice", "agreedPrice", "initialPayment", "paymentMethod", "cryptoPercentage", "fiatPercentage", "offerMessage", "offerTerms", "proposalDate", "acceptanceDate", "escrowDate", "completionDate", "deadlineDate", "buyerHasRep", "sellerHasRep", "mediationSigned", "purchaseAgreementSigned", "createdAt", "updatedAt", "buyerSignedPromissory", "buyerSignedPromissoryAt", "purchaseAgreementSignedAt", "sellerSignedPromissory", "sellerSignedPromissoryAt", "buyerKyc2Verified", "buyerKyc2VerifiedAt", "sellerKyc2Verified", "sellerKyc2VerifiedAt", "kyc2StartedAt", "fundProtectionDate") FROM stdin;
cmfqt4sef0001h2r1ph4j43vn	cmfqptx630002h26lmvzj0tvd	cmfqptx660003h26llurbau9n	cmfqrfvpi0001h27y5vwyur33	AGREEMENT	250000.000000000000000000000000000000	262000.000000000000000000000000000000	\N	HYBRID	60	40	Test offer	Standard terms	2025-09-19 12:19:58.022	2025-09-19 12:22:25.286	\N	\N	\N	f	f	f	t	2025-09-19 12:19:58.023	2025-09-19 12:29:17.515	t	2025-09-19 12:22:54.755	\N	t	2025-09-19 12:29:17.512	f	\N	f	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.users (id, email, password, "emailVerified", role, "firstName", "lastName", phone, "phoneNumber", "phoneVerified", "dateOfBirth", "addressLine1", city, state, "postalCode", country, "paymentPreference", "strigaUserId", "kycStatus", "kycSessionId", "kyc2Status", "kyc2SessionId", "kyc2CompletedAt", "createdAt", "updatedAt") FROM stdin;
cmfqptx350000h26l748hs4s0	f@pachoman.com	$2b$10$uyzyFVR5/So5zI7oxrbhGuEucyAZnYl88k/EtE3nGxBZpSj.YByiu	\N	ADMIN	Admin	User	+351000000000	\N	f	1980-01-01 00:00:00	Admin Street 1	Lisbon	\N	1000-000	PT	HYBRID	\N	PASSED	\N	PENDING	\N	\N	2025-09-19 10:47:32.033	2025-09-19 10:47:32.033
cmfqptx630002h26lmvzj0tvd	buyer@test.com	$2b$10$BRarhpBz//7p9zh0UuZSGepmuY/HkC3lczXIcpH/FniNeqX9xqft2	2025-09-19 10:57:14.48	BUYER	Test	Buyer	+351900000001	\N	t	1990-01-01 00:00:00	Buyer Street 1	Porto	\N	4000-000	PT	FIAT	8d356d73-0905-40c1-900d-59f7a75d55b5	PASSED	\N	PENDING	\N	\N	2025-09-19 10:47:32.14	2025-09-19 10:57:14.48
cmfqptx660003h26llurbau9n	seller@test.com	$2b$10$BRarhpBz//7p9zh0UuZSGepmuY/HkC3lczXIcpH/FniNeqX9xqft2	2025-09-19 10:57:16.836	SELLER	Test	Seller	+351900000002	\N	t	1985-01-01 00:00:00	Seller Avenue 1	Faro	\N	8000-000	PT	FIAT	b3d32c24-4c4f-4db2-9873-04eb0987fa37	PASSED	\N	PENDING	\N	\N	2025-09-19 10:47:32.142	2025-09-19 10:57:16.837
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.wallets (id, "userId", "strigaWalletId", currency, address, "qrCode", balance, "lastSyncAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.webhook_events (id, "eventType", source, "eventId", payload, processed, "processedAt", error, "createdAt") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: counter_offers counter_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.counter_offers
    ADD CONSTRAINT counter_offers_pkey PRIMARY KEY (id);


--
-- Name: digital_ibans digital_ibans_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.digital_ibans
    ADD CONSTRAINT digital_ibans_pkey PRIMARY KEY (id);


--
-- Name: document_access document_access_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT document_access_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: escrow_details escrow_details_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_details
    ADD CONSTRAINT escrow_details_pkey PRIMARY KEY (id);


--
-- Name: escrow_steps escrow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_steps
    ADD CONSTRAINT escrow_steps_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: legal_templates legal_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.legal_templates
    ADD CONSTRAINT legal_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_audits property_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT property_audits_pkey PRIMARY KEY (id);


--
-- Name: property_interests property_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT property_interests_pkey PRIMARY KEY (id);


--
-- Name: transaction_status_history transaction_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transaction_status_history
    ADD CONSTRAINT transaction_status_history_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts_userId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "bank_accounts_userId_key" ON public.bank_accounts USING btree ("userId");


--
-- Name: digital_ibans_iban_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX digital_ibans_iban_key ON public.digital_ibans USING btree (iban);


--
-- Name: document_access_propertyId_buyerId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "document_access_propertyId_buyerId_key" ON public.document_access USING btree ("propertyId", "buyerId");


--
-- Name: escrow_details_transactionId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "escrow_details_transactionId_key" ON public.escrow_details USING btree ("transactionId");


--
-- Name: escrow_steps_transactionId_stepNumber_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "escrow_steps_transactionId_stepNumber_key" ON public.escrow_steps USING btree ("transactionId", "stepNumber");


--
-- Name: profiles_userId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "profiles_userId_key" ON public.profiles USING btree ("userId");


--
-- Name: properties_code_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX properties_code_key ON public.properties USING btree (code);


--
-- Name: property_interests_propertyId_buyerId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "property_interests_propertyId_buyerId_key" ON public.property_interests USING btree ("propertyId", "buyerId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_strigaUserId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "users_strigaUserId_key" ON public.users USING btree ("strigaUserId");


--
-- Name: wallets_strigaWalletId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "wallets_strigaWalletId_key" ON public.wallets USING btree ("strigaWalletId");


--
-- Name: wallets_userId_currency_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "wallets_userId_currency_key" ON public.wallets USING btree ("userId", currency);


--
-- Name: webhook_events_source_eventId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "webhook_events_source_eventId_key" ON public.webhook_events USING btree (source, "eventId");


--
-- Name: bank_accounts bank_accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT "bank_accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: counter_offers counter_offers_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.counter_offers
    ADD CONSTRAINT "counter_offers_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: digital_ibans digital_ibans_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.digital_ibans
    ADD CONSTRAINT "digital_ibans_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_grantedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_grantedBy_fkey" FOREIGN KEY ("grantedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: escrow_details escrow_details_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_details
    ADD CONSTRAINT "escrow_details_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: escrow_steps escrow_steps_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_steps
    ADD CONSTRAINT "escrow_steps_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interviews interviews_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profiles profiles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: properties properties_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT "properties_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: property_audits property_audits_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT "property_audits_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: property_audits property_audits_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT "property_audits_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_interests property_interests_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT "property_interests_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_interests property_interests_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT "property_interests_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaction_status_history transaction_status_history_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transaction_status_history
    ADD CONSTRAINT "transaction_status_history_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions transactions_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions transactions_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: wallets wallets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT "wallets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict XImyldU6IFyJG3cLU7fMAQNCKy6N897D2Z2yD6R1lnsvMUjmbOyXl349ntbTZyh

