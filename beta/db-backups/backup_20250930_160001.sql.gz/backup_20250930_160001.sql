--
-- PostgreSQL database dump
--

\restrict X5UH91oozuzbD6a4vDk5BEqm7vOu82xVSk2JkJKMeGOa5SyKm6qtFAmdYrEWcJN

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ComplianceStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."ComplianceStatus" AS ENUM (
    'PENDING',
    'REJECTED',
    'APPROVED'
);


ALTER TYPE public."ComplianceStatus" OWNER TO caenhebo;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."DocumentType" AS ENUM (
    'ENERGY_CERTIFICATE',
    'MUNICIPAL_LICENSE',
    'PREDIAL_REGISTRATION',
    'CADERNETA_PREDIAL_URBANA',
    'COMPLIANCE_DECLARATION',
    'REPRESENTATION_DOCUMENT',
    'MEDIATION_AGREEMENT',
    'PURCHASE_AGREEMENT',
    'PAYMENT_PROOF',
    'NOTARIZED_DOCUMENT',
    'TITLE_DEED',
    'CERTIFICATE',
    'PHOTO',
    'FLOOR_PLAN',
    'OTHER',
    'USAGE_LICENSE',
    'LAND_REGISTRY',
    'TAX_REGISTER',
    'OWNER_AUTHORIZATION',
    'CONTRACT',
    'PROOF_OF_PAYMENT',
    'LEGAL_DOCUMENT',
    'PERSONAL_ID'
);


ALTER TYPE public."DocumentType" OWNER TO caenhebo;

--
-- Name: KycStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."KycStatus" AS ENUM (
    'PENDING',
    'INITIATED',
    'PASSED',
    'REJECTED',
    'EXPIRED'
);


ALTER TYPE public."KycStatus" OWNER TO caenhebo;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."NotificationType" AS ENUM (
    'NEW_OFFER',
    'OFFER_ACCEPTED',
    'OFFER_REJECTED',
    'COUNTER_OFFER',
    'PROPERTY_APPROVED',
    'PROPERTY_REJECTED',
    'PROPERTY_INTEREST',
    'DOCUMENT_UPLOADED',
    'TRANSACTION_STATUS_CHANGE',
    'KYC_STATUS_CHANGE',
    'INTERVIEW_SCHEDULED'
);


ALTER TYPE public."NotificationType" OWNER TO caenhebo;

--
-- Name: PaymentPreference; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."PaymentPreference" AS ENUM (
    'CRYPTO',
    'FIAT',
    'HYBRID'
);


ALTER TYPE public."PaymentPreference" OWNER TO caenhebo;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."PaymentStatus" OWNER TO caenhebo;

--
-- Name: PropertyType; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."PropertyType" AS ENUM (
    'APARTMENT',
    'HOUSE',
    'OFFICE',
    'BUILDING',
    'LOT'
);


ALTER TYPE public."PropertyType" OWNER TO caenhebo;

--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'OFFER',
    'NEGOTIATION',
    'AGREEMENT',
    'KYC2_VERIFICATION',
    'FUND_PROTECTION',
    'CLOSING',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."TransactionStatus" OWNER TO caenhebo;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: caenhebo
--

CREATE TYPE public."UserRole" AS ENUM (
    'BUYER',
    'SELLER',
    'ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO caenhebo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO caenhebo;

--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.bank_accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    "accountHolderName" text NOT NULL,
    "bankName" text NOT NULL,
    iban text NOT NULL,
    "swiftCode" text,
    "bankAddress" text,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "accountType" text,
    verified boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_accounts OWNER TO caenhebo;

--
-- Name: counter_offers; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.counter_offers (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    price numeric(65,30) NOT NULL,
    "advancePaymentPercentage" integer DEFAULT 0,
    message text,
    terms text,
    "fromBuyer" boolean NOT NULL,
    accepted boolean DEFAULT false NOT NULL,
    rejected boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.counter_offers OWNER TO caenhebo;

--
-- Name: digital_ibans; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.digital_ibans (
    id text NOT NULL,
    "userId" text NOT NULL,
    iban text NOT NULL,
    "bankName" text,
    "accountNumber" text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.digital_ibans OWNER TO caenhebo;

--
-- Name: document_access; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.document_access (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "buyerId" text NOT NULL,
    "grantedBy" text NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    revoked boolean DEFAULT false NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    message text
);


ALTER TABLE public.document_access OWNER TO caenhebo;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "userId" text,
    "transactionId" text,
    "propertyId" text,
    type public."DocumentType" NOT NULL,
    filename text NOT NULL,
    "originalName" text,
    url text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    title text,
    description text,
    verified boolean DEFAULT false NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    signed boolean DEFAULT false NOT NULL,
    "signedAt" timestamp(3) without time zone,
    "signedBy" text,
    signature text,
    "adminComment" text,
    "adminApprovalStatus" public."ComplianceStatus" DEFAULT 'PENDING'::public."ComplianceStatus",
    "adminReviewedAt" timestamp(3) without time zone,
    "adminReviewedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.documents OWNER TO caenhebo;

--
-- Name: escrow_details; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.escrow_details (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "escrowAccountId" text,
    "escrowProvider" text,
    "totalAmount" numeric(65,30) NOT NULL,
    "initialDeposit" numeric(65,30),
    "finalPayment" numeric(65,30),
    "releaseConditions" text,
    "fundsReceived" boolean DEFAULT false NOT NULL,
    "fundsReleased" boolean DEFAULT false NOT NULL,
    "fundingDate" timestamp(3) without time zone,
    "releaseDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.escrow_details OWNER TO caenhebo;

--
-- Name: fund_protection_steps; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.fund_protection_steps (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "stepNumber" integer NOT NULL,
    "stepType" text NOT NULL,
    description text NOT NULL,
    "userType" text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    amount numeric(65,30),
    currency text,
    "fromWalletId" text,
    "toWalletId" text,
    "txHash" text,
    "proofUrl" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.fund_protection_steps OWNER TO caenhebo;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.interviews (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    duration integer DEFAULT 60 NOT NULL,
    notes text,
    completed boolean DEFAULT false NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    "conductedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.interviews OWNER TO caenhebo;

--
-- Name: legal_templates; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.legal_templates (
    id text NOT NULL,
    name text NOT NULL,
    type public."DocumentType" NOT NULL,
    content text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.legal_templates OWNER TO caenhebo;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    data jsonb,
    read boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    "transactionId" text,
    "propertyId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO caenhebo;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    type public."PaymentPreference" NOT NULL,
    amount numeric(65,30) NOT NULL,
    currency text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "walletAddress" text,
    "txHash" text,
    "bankDetails" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO caenhebo;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    bio text,
    avatar text,
    "companyName" text,
    "taxId" text,
    "dateOfBirth" timestamp(3) without time zone,
    address text,
    "addressLine2" text,
    city text,
    "postalCode" text,
    country text,
    "termsAcceptedAt" timestamp(3) without time zone,
    "privacyAcceptedAt" timestamp(3) without time zone,
    "amlAcceptedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.profiles OWNER TO caenhebo;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.properties (
    id text NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    description text,
    address text NOT NULL,
    city text NOT NULL,
    state text,
    "postalCode" text NOT NULL,
    country text DEFAULT 'Portugal'::text NOT NULL,
    price numeric(65,30) NOT NULL,
    area double precision,
    bedrooms integer,
    bathrooms integer,
    "sellerId" text NOT NULL,
    "complianceStatus" public."ComplianceStatus" DEFAULT 'PENDING'::public."ComplianceStatus" NOT NULL,
    "complianceNotes" text,
    "valuationPrice" numeric(65,30),
    "interviewDate" timestamp(3) without time zone,
    "interviewStatus" text DEFAULT 'NOT_SCHEDULED'::text NOT NULL,
    "interviewNotes" text,
    "finalApprovalStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "isVisible" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    diagrams text[],
    photos text[],
    "propertyType" public."PropertyType"
);


ALTER TABLE public.properties OWNER TO caenhebo;

--
-- Name: property_audits; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.property_audits (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "adminId" text NOT NULL,
    notes text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.property_audits OWNER TO caenhebo;

--
-- Name: property_interests; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.property_interests (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "buyerId" text NOT NULL,
    "interestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    message text
);


ALTER TABLE public.property_interests OWNER TO caenhebo;

--
-- Name: transaction_status_history; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.transaction_status_history (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "fromStatus" public."TransactionStatus",
    "toStatus" public."TransactionStatus" NOT NULL,
    "changedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transaction_status_history OWNER TO caenhebo;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    "buyerId" text NOT NULL,
    "sellerId" text NOT NULL,
    "propertyId" text NOT NULL,
    status public."TransactionStatus" DEFAULT 'OFFER'::public."TransactionStatus" NOT NULL,
    "offerPrice" numeric(65,30) NOT NULL,
    "agreedPrice" numeric(65,30),
    "initialPayment" numeric(65,30),
    "advancePaymentPercentage" integer DEFAULT 0,
    "paymentMethod" public."PaymentPreference" DEFAULT 'FIAT'::public."PaymentPreference" NOT NULL,
    "cryptoPercentage" integer,
    "fiatPercentage" integer,
    "offerMessage" text,
    "offerTerms" text,
    "proposalDate" timestamp(3) without time zone,
    "acceptanceDate" timestamp(3) without time zone,
    "escrowDate" timestamp(3) without time zone,
    "completionDate" timestamp(3) without time zone,
    "deadlineDate" timestamp(3) without time zone,
    "buyerHasRep" boolean DEFAULT false NOT NULL,
    "sellerHasRep" boolean DEFAULT false NOT NULL,
    "mediationSigned" boolean DEFAULT false NOT NULL,
    "purchaseAgreementSigned" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "buyerSignedPromissory" boolean DEFAULT false,
    "buyerSignedPromissoryAt" timestamp(3) without time zone,
    "purchaseAgreementSignedAt" timestamp(3) without time zone,
    "sellerSignedPromissory" boolean DEFAULT false,
    "sellerSignedPromissoryAt" timestamp(3) without time zone,
    "buyerSignedMediation" boolean DEFAULT false,
    "buyerSignedMediationAt" timestamp(3) without time zone,
    "sellerSignedMediation" boolean DEFAULT false,
    "sellerSignedMediationAt" timestamp(3) without time zone,
    "buyerKyc2Verified" boolean DEFAULT false NOT NULL,
    "buyerKyc2VerifiedAt" timestamp(3) without time zone,
    "sellerKyc2Verified" boolean DEFAULT false NOT NULL,
    "sellerKyc2VerifiedAt" timestamp(3) without time zone,
    "kyc2StartedAt" timestamp(3) without time zone,
    "fundProtectionDate" timestamp(3) without time zone
);


ALTER TABLE public.transactions OWNER TO caenhebo;

--
-- Name: users; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    role public."UserRole" DEFAULT 'BUYER'::public."UserRole" NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    "phoneNumber" text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "dateOfBirth" timestamp(3) without time zone,
    "addressLine1" text,
    city text,
    state text,
    "postalCode" text,
    country text,
    "paymentPreference" public."PaymentPreference" DEFAULT 'FIAT'::public."PaymentPreference" NOT NULL,
    "strigaUserId" text,
    "kycStatus" public."KycStatus" DEFAULT 'PENDING'::public."KycStatus" NOT NULL,
    "kycSessionId" text,
    "kyc2Status" public."KycStatus" DEFAULT 'PENDING'::public."KycStatus" NOT NULL,
    "kyc2SessionId" text,
    "kyc2CompletedAt" timestamp(3) without time zone,
    "mediationAgreementSigned" boolean DEFAULT false NOT NULL,
    "mediationAgreementSignedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO caenhebo;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.wallets (
    id text NOT NULL,
    "userId" text NOT NULL,
    "strigaWalletId" text NOT NULL,
    currency text NOT NULL,
    address text,
    "qrCode" text,
    balance numeric(65,30) DEFAULT 0 NOT NULL,
    "lastSyncAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.wallets OWNER TO caenhebo;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: caenhebo
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    "eventType" text NOT NULL,
    source text NOT NULL,
    "eventId" text,
    payload jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_events OWNER TO caenhebo;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
69d1e099-163d-4e3a-ae0e-343f783a3d7e	b188e54574bbe84a5d414abcf09c08e9b5df151f1e237eb226400208e617d003	\N	20250109_add_promissory_fields	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250109_add_promissory_fields\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "transactions" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"transactions\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(433), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	\N	2025-09-30 07:17:45.155116+00	0
6d481ae6-02c9-42a8-93bd-7d6a7afce5a8	b188e54574bbe84a5d414abcf09c08e9b5df151f1e237eb226400208e617d003	\N	20250109_add_promissory_fields	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250109_add_promissory_fields\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "transactions" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"transactions\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(433), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250109_add_promissory_fields"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-09-19 10:35:50.876306+00	2025-09-19 10:35:36.354925+00	0
36e96d38-ec5f-4a35-81a6-301280c2624b	b188e54574bbe84a5d414abcf09c08e9b5df151f1e237eb226400208e617d003	2025-09-19 10:35:50.877154+00	20250109_add_promissory_fields		\N	2025-09-19 10:35:50.877154+00	0
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.bank_accounts (id, "userId", "accountHolderName", "bankName", iban, "swiftCode", "bankAddress", currency, "accountType", verified, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: counter_offers; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.counter_offers (id, "transactionId", price, "advancePaymentPercentage", message, terms, "fromBuyer", accepted, rejected, "createdAt") FROM stdin;
\.


--
-- Data for Name: digital_ibans; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.digital_ibans (id, "userId", iban, "bankName", "accountNumber", active, "createdAt", "updatedAt") FROM stdin;
cmfqq7bn10001h2vdtnhcdvvx	cmfqptx630002h26lmvzj0tvd	PT50003506090000a75d55b5	Striga Bank (Test)	f7a75d55b5	t	2025-09-19 10:57:57.422	2025-09-19 10:57:57.422
cmfqqow9a0005h2vdmuj0fn94	cmfqptx660003h26llurbau9n	PT500035060900000987fa37	Striga Bank (Test)	eb0987fa37	t	2025-09-19 11:11:37.295	2025-09-19 11:11:37.295
cmfqzskkr000lh2otykn8n9pa	cmfqzlep4000gh2otifdq4dj0	PT50003506090000f4cb2dd3	Striga Bank (Test)	9cf4cb2dd3	t	2025-09-19 15:26:25.323	2025-09-19 15:26:25.323
cmfr1fy9c001nh2otda6oe7gw	cmfr17ro5001ih2ot5z5v8yu4	PT5000350609000044be6fef	Striga Bank (Test)	a944be6fef	t	2025-09-19 16:12:35.761	2025-09-19 16:12:35.761
\.


--
-- Data for Name: document_access; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.document_access (id, "propertyId", "buyerId", "grantedBy", "grantedAt", "expiresAt", revoked, "revokedAt", message) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.documents (id, "userId", "transactionId", "propertyId", type, filename, "originalName", url, "mimeType", size, title, description, verified, "uploadedAt", signed, "signedAt", "signedBy", signature, "adminComment", "adminApprovalStatus", "adminReviewedAt", "adminReviewedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: escrow_details; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.escrow_details (id, "transactionId", "escrowAccountId", "escrowProvider", "totalAmount", "initialDeposit", "finalPayment", "releaseConditions", "fundsReceived", "fundsReleased", "fundingDate", "releaseDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: fund_protection_steps; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.fund_protection_steps (id, "transactionId", "stepNumber", "stepType", description, "userType", status, amount, currency, "fromWalletId", "toWalletId", "txHash", "proofUrl", "completedAt", "createdAt", "updatedAt") FROM stdin;
cmg6mu9of0002h24sc0wo35rh	cmg6htwz80007h2vyigovql8o	1	FIAT_UPLOAD	Upload proof of €1500000.00 bank transfer to seller	BUYER	COMPLETED	1500000.000000000000000000000000000000	EUR	\N	\N	\N	/uploads/fiat-proofs/fiat_proof_cmg6htwz80007h2vyigovql8o_e79UHy5WEkL9M693xYMZF.pdf	2025-09-30 14:11:20.468	2025-09-30 14:08:08.32	2025-09-30 14:11:20.469
cmg6mu9of0003h24s8qouos19	cmg6htwz80007h2vyigovql8o	2	FIAT_CONFIRM	Confirm receipt of €1500000.00 payment	SELLER	COMPLETED	1500000.000000000000000000000000000000	EUR	\N	\N	\N	\N	2025-09-30 14:15:26.857	2025-09-30 14:08:08.32	2025-09-30 14:15:26.857
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.interviews (id, "propertyId", "scheduledAt", duration, notes, completed, approved, "conductedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: legal_templates; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.legal_templates (id, name, type, content, version, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.notifications (id, "userId", type, title, message, data, read, "readAt", "transactionId", "propertyId", "createdAt", "updatedAt") FROM stdin;
cmfqq7bn40003h2vd13tg6tif	cmfqptx630002h26lmvzj0tvd	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 10:57:57.424	2025-09-19 10:57:57.424
cmfqqow9c0007h2vddnywnbxr	cmfqptx660003h26llurbau9n	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 11:11:37.297	2025-09-19 11:11:37.297
cmfqsjhg60009h2s8qi799w3s	cmfqptx660003h26llurbau9n	PROPERTY_APPROVED	Property Approved	Your property "3 bedroom house" has been approved and is now live! Property code: CAE-2025-0001	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": 0, "title": "3 bedroom house", "address": ""}}	f	\N	\N	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:03:24.054	2025-09-19 12:03:24.054
cmfqt4sew0005h2r1beny9zv3	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €250,000 on 3 bedroom house	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": "3520000", "title": "3 bedroom house", "address": "fdasfddf"}, "transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "OFFER", "offerPrice": 250000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:19:58.041	2025-09-19 12:19:58.041
cmfqt7ftt000bh2r1uyg10vu4	cmfqptx630002h26lmvzj0tvd	COUNTER_OFFER	Counter Offer Received	Test Seller made a counter-offer of €262,000 for 3 bedroom house	{"other": {"fromBuyer": false}, "transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "NEGOTIATION", "offerPrice": 262000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:22:01.697	2025-09-19 12:22:01.697
cmfqt7y17000fh2r19dheckjt	cmfqptx660003h26llurbau9n	OFFER_ACCEPTED	Offer Accepted!	Test Buyer accepted your offer of €262,000 for 3 bedroom house	{"transaction": {"id": "cmfqt4sef0001h2r1ph4j43vn", "status": "AGREEMENT", "offerPrice": 262000}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 12:22:25.291	2025-09-19 12:22:25.291
cmfqv7qv70003h2wd1wdw9mj1	cmfqptx660003h26llurbau9n	DOCUMENT_UPLOADED	New Documents Uploaded	buyer@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 13:18:15.235	2025-09-19 13:18:15.235
cmfqvee050003h2jxpzntfghy	cmfqptx660003h26llurbau9n	DOCUMENT_UPLOADED	New Documents Uploaded	buyer@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfqt4sef0001h2r1ph4j43vn	cmfqrfvpi0001h27y5vwyur33	2025-09-19 13:23:25.157	2025-09-19 13:23:25.157
cmfqvijv30001h2t0ypd2bdaz	cmfqptx630002h26lmvzj0tvd	TRANSACTION_STATUS_CHANGE	Mediation Agreement Complete	Both parties have signed the mediation agreement for transaction ph4j43vn	{"action": "mediation_signed", "bothSigned": true, "signerRole": "seller", "transactionId": "cmfqt4sef0001h2r1ph4j43vn"}	f	\N	cmfqt4sef0001h2r1ph4j43vn	\N	2025-09-19 13:26:39.375	2025-09-19 13:26:39.375
cmfqzgtco000fh2otxcnpzb64	cmfqptx660003h26llurbau9n	PROPERTY_APPROVED	Property Approved	Your property "2 bedroom" has been approved and is now live! Property code: CAE-2025-0002	{"property": {"id": "cmfqz0gms0001h2ot3dyehmrb", "code": "CAE-2025-0002", "price": 0, "title": "2 bedroom", "address": ""}}	f	\N	\N	cmfqz0gms0001h2ot3dyehmrb	2025-09-19 15:17:16.824	2025-09-19 15:17:16.824
cmfqzskks000nh2ottzaa236d	cmfqzlep4000gh2otifdq4dj0	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 15:26:25.325	2025-09-19 15:26:25.325
cmfqzuyxd000th2othrp4xwjt	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €25,111 on 2 bedroom	{"property": {"id": "cmfqz0gms0001h2ot3dyehmrb", "code": "CAE-2025-0002", "price": "2501000", "title": "2 bedroom", "address": "adfasd"}, "transaction": {"id": "cmfqzuywy000ph2otnbkgvxjw", "status": "OFFER", "offerPrice": 25111}}	f	\N	cmfqzuywy000ph2otnbkgvxjw	cmfqz0gms0001h2ot3dyehmrb	2025-09-19 15:28:17.234	2025-09-19 15:28:17.234
cmfr00hir000xh2ot7rjs27rw	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Test Seller accepted your offer of €25,111 for 2 bedroom	{"transaction": {"id": "cmfqzuywy000ph2otnbkgvxjw", "status": "AGREEMENT", "offerPrice": 25111}}	t	2025-09-19 15:47:21.794	cmfqzuywy000ph2otnbkgvxjw	cmfqz0gms0001h2ot3dyehmrb	2025-09-19 15:32:34.612	2025-09-19 15:47:21.795
cmfr0n2o90017h2ot9rgzjomy	cmfqptx660003h26llurbau9n	DOCUMENT_UPLOADED	New Documents Uploaded	buyer@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfqzuywy000ph2otnbkgvxjw	cmfqz0gms0001h2ot3dyehmrb	2025-09-19 15:50:08.458	2025-09-19 15:50:08.458
cmfr0n8or0019h2otm80wo3au	cmfqptx660003h26llurbau9n	TRANSACTION_STATUS_CHANGE	Mediation Agreement Signed	buyer@test.com has signed the mediation agreement for transaction nbkgvxjw	{"action": "mediation_signed", "bothSigned": false, "signerRole": "buyer", "transactionId": "cmfqzuywy000ph2otnbkgvxjw"}	t	2025-09-19 15:50:38.695	cmfqzuywy000ph2otnbkgvxjw	\N	2025-09-19 15:50:16.251	2025-09-19 15:50:38.696
cmfr0ny4s001dh2otpd2qs6rt	cmfqptx630002h26lmvzj0tvd	DOCUMENT_UPLOADED	New Documents Uploaded	seller@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfqzuywy000ph2otnbkgvxjw	cmfqz0gms0001h2ot3dyehmrb	2025-09-19 15:50:49.229	2025-09-19 15:50:49.229
cmfr0o0ay001fh2ot9xe2slhc	cmfqptx630002h26lmvzj0tvd	TRANSACTION_STATUS_CHANGE	Mediation Agreement Complete	Both parties have signed the mediation agreement for transaction nbkgvxjw	{"action": "mediation_signed", "bothSigned": true, "signerRole": "seller", "transactionId": "cmfqzuywy000ph2otnbkgvxjw"}	f	\N	cmfqzuywy000ph2otnbkgvxjw	\N	2025-09-19 15:50:52.043	2025-09-19 15:50:52.043
cmfr0t81d001hh2oti38yao5n	cmfqptx630002h26lmvzj0tvd	KYC_STATUS_CHANGE	KYC2 Verification Progress	seller@test.com has completed KYC2 verification for transaction nbkgvxjw	{"action": "kyc2_completed", "bothVerified": false, "verifierRole": "seller", "transactionId": "cmfqzuywy000ph2otnbkgvxjw"}	f	\N	cmfqzuywy000ph2otnbkgvxjw	\N	2025-09-19 15:54:55.346	2025-09-19 15:54:55.346
cmfr1fy9e001ph2otmquupnf6	cmfr17ro5001ih2ot5z5v8yu4	KYC_STATUS_CHANGE	Payment Account Created	Your EUR payment account has been successfully created with banking details.	\N	f	\N	\N	\N	2025-09-19 16:12:35.763	2025-09-19 16:12:35.763
cmfr2g0f60027h2ot6am3qf5k	cmfr17ro5001ih2ot5z5v8yu4	PROPERTY_APPROVED	Property Approved	Your property "3 bedroom" has been approved and is now live! Property code: CAE-2025-0003	{"property": {"id": "cmfr1wdd0001rh2oty4ros5td", "code": "CAE-2025-0003", "price": 0, "title": "3 bedroom", "address": ""}}	f	\N	\N	cmfr1wdd0001rh2oty4ros5td	2025-09-19 16:40:38.178	2025-09-19 16:40:38.178
cmfr2okd8002bh2otc2wys6uc	cmfr17ro5001ih2ot5z5v8yu4	PROPERTY_INTEREST	New Interest in Your Property	Test Buyer has expressed interest in your property "3 bedroom" (CAE-2025-0003)	{"buyerId": "cmfqptx630002h26lmvzj0tvd", "message": null, "buyerName": "Test Buyer", "buyerEmail": "buyer@test.com", "propertyId": "cmfr1wdd0001rh2oty4ros5td", "propertyCode": "CAE-2025-0003", "propertyTitle": "3 bedroom"}	f	\N	\N	cmfr1wdd0001rh2oty4ros5td	2025-09-19 16:47:17.277	2025-09-19 16:47:17.277
cmfr2q6ba002hh2otfeo734u1	cmfr17ro5001ih2ot5z5v8yu4	NEW_OFFER	New Offer Received	Test Buyer made an offer of €325,000 on 3 bedroom	{"property": {"id": "cmfr1wdd0001rh2oty4ros5td", "code": "CAE-2025-0003", "price": "3500000", "title": "3 bedroom", "address": "cadsfdasdf"}, "transaction": {"id": "cmfr2q6b3002dh2ot1ipegzgf", "status": "OFFER", "offerPrice": 325000}}	t	2025-09-19 16:49:14.934	cmfr2q6b3002dh2ot1ipegzgf	cmfr1wdd0001rh2oty4ros5td	2025-09-19 16:48:32.375	2025-09-19 16:49:14.935
cmfr3867b002lh2ota7kua8r1	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Bruno registers accepted your offer of €325,000 for 3 bedroom	{"transaction": {"id": "cmfr2q6b3002dh2ot1ipegzgf", "status": "AGREEMENT", "offerPrice": 325000}}	t	2025-09-19 17:09:24.389	cmfr2q6b3002dh2ot1ipegzgf	cmfr1wdd0001rh2oty4ros5td	2025-09-19 17:02:32.04	2025-09-19 17:09:24.389
cmfsag63f0039h2otje70n9c8	cmfqptx660003h26llurbau9n	PROPERTY_APPROVED	Property Approved	Your property "tatiana 3bedrrom" has been approved and is now live! Property code: CAE-2025-0004	{"property": {"id": "cmfsabd2q002th2oty827xaik", "code": "CAE-2025-0004", "price": 0, "title": "tatiana 3bedrrom", "address": ""}}	f	\N	\N	cmfsabd2q002th2oty827xaik	2025-09-20 13:12:28.636	2025-09-20 13:12:28.636
cmfsait6a003fh2ot4n17b3sx	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €250,000 on tatiana 3bedrrom	{"property": {"id": "cmfsabd2q002th2oty827xaik", "code": "CAE-2025-0004", "price": "8500000", "title": "tatiana 3bedrrom", "address": "dsfadfsa"}, "transaction": {"id": "cmfsait65003bh2otwfklp8o1", "status": "OFFER", "offerPrice": 250000}}	f	\N	cmfsait65003bh2otwfklp8o1	cmfsabd2q002th2oty827xaik	2025-09-20 13:14:31.859	2025-09-20 13:14:31.859
cmfseobf8003ph2ot2th7brey	cmfqptx630002h26lmvzj0tvd	COUNTER_OFFER	Counter Offer Received	Test Seller made a counter-offer of €25,550,000 for tatiana 3bedrrom	{"other": {"fromBuyer": false}, "transaction": {"id": "cmfsait65003bh2otwfklp8o1", "status": "NEGOTIATION", "offerPrice": 25550000}}	t	2025-09-20 15:10:59.551	cmfsait65003bh2otwfklp8o1	cmfsabd2q002th2oty827xaik	2025-09-20 15:10:47.252	2025-09-20 15:10:59.552
cmfser1v5003th2ot706k8y64	cmfqptx660003h26llurbau9n	OFFER_ACCEPTED	Offer Accepted!	Test Buyer accepted your offer of €25,550,000 for tatiana 3bedrrom	{"transaction": {"id": "cmfsait65003bh2otwfklp8o1", "status": "AGREEMENT", "offerPrice": 25550000}}	f	\N	cmfsait65003bh2otwfklp8o1	cmfsabd2q002th2oty827xaik	2025-09-20 15:12:54.833	2025-09-20 15:12:54.833
cmfsew8850043h2ot3pxc2n4t	cmfqptx630002h26lmvzj0tvd	DOCUMENT_UPLOADED	New Documents Uploaded	seller@test.com uploaded 1 document for the transaction	{"documents": {"count": 1, "types": ["REPRESENTATION_DOCUMENT"]}}	f	\N	cmfsait65003bh2otwfklp8o1	cmfsabd2q002th2oty827xaik	2025-09-20 15:16:56.358	2025-09-20 15:16:56.358
cmfsew9vz0045h2ote5sf0tkk	cmfqptx630002h26lmvzj0tvd	TRANSACTION_STATUS_CHANGE	Mediation Agreement Signed	seller@test.com has signed the mediation agreement for transaction wfklp8o1	{"action": "mediation_signed", "bothSigned": false, "signerRole": "seller", "transactionId": "cmfsait65003bh2otwfklp8o1"}	f	\N	cmfsait65003bh2otwfklp8o1	\N	2025-09-20 15:16:58.512	2025-09-20 15:16:58.512
cmfz797580005h2zaaolxbstc	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €10 on 2 bedroom	{"property": {"id": "cmfqz0gms0001h2ot3dyehmrb", "code": "CAE-2025-0002", "price": "2501000", "title": "2 bedroom", "address": "adfasd"}, "transaction": {"id": "cmfz7974t0001h2zasvuvka3a", "status": "OFFER", "offerPrice": 10}}	f	\N	cmfz7974t0001h2zasvuvka3a	cmfqz0gms0001h2ot3dyehmrb	2025-09-25 09:17:27.788	2025-09-25 09:17:27.788
cmfz7aeq8000bh2zag8ou7kub	cmfqptx630002h26lmvzj0tvd	COUNTER_OFFER	Counter Offer Received	Test Seller made a counter-offer of €2 for 2 bedroom	{"other": {"fromBuyer": false}, "transaction": {"id": "cmfz7974t0001h2zasvuvka3a", "status": "NEGOTIATION", "offerPrice": 2}}	f	\N	cmfz7974t0001h2zasvuvka3a	cmfqz0gms0001h2ot3dyehmrb	2025-09-25 09:18:24.273	2025-09-25 09:18:24.273
cmfz7chk1000fh2za44vy4gz0	cmfqptx660003h26llurbau9n	OFFER_ACCEPTED	Offer Accepted!	Test Buyer accepted your offer of €2 for 2 bedroom	{"transaction": {"id": "cmfz7974t0001h2zasvuvka3a", "status": "AGREEMENT", "offerPrice": 2}}	f	\N	cmfz7974t0001h2zasvuvka3a	cmfqz0gms0001h2ot3dyehmrb	2025-09-25 09:20:01.25	2025-09-25 09:20:01.25
cmg0k8u5t0003h2brpjldwzb3	cmfqptx660003h26llurbau9n	DOCUMENT_UPLOADED	Document rejected	Your document has been rejected: i dont like him, he is from REMAX	\N	f	\N	\N	cmfsabd2q002th2oty827xaik	2025-09-26 08:08:52.145	2025-09-26 08:08:52.145
cmg0ksgbl000fh2brmvzmxa0u	cmfqptx630002h26lmvzj0tvd	COUNTER_OFFER	Counter Offer Received	Test Seller made a counter-offer of €2,510,000 for 3 bedroom house	{"other": {"fromBuyer": false}, "transaction": {"id": "cmg0knk3k0005h2br2t8zunlx", "status": "NEGOTIATION", "offerPrice": 2510000}}	f	\N	cmg0knk3k0005h2br2t8zunlx	cmfqrfvpi0001h27y5vwyur33	2025-09-26 08:24:07.329	2025-09-26 08:24:07.329
cmg0ksz79000jh2brzvmp5pgw	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Test Seller accepted your offer of €2,510,000 for 3 bedroom house	{"transaction": {"id": "cmg0knk3k0005h2br2t8zunlx", "status": "AGREEMENT", "offerPrice": 2510000}}	f	\N	cmg0knk3k0005h2br2t8zunlx	cmfqrfvpi0001h27y5vwyur33	2025-09-26 08:24:31.798	2025-09-26 08:24:31.798
cmg0knk3u0009h2brnlzs00bx	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €250,000 on 3 bedroom house	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": "3520000", "title": "3 bedroom house", "address": "fdasfddf"}, "transaction": {"id": "cmg0knk3k0005h2br2t8zunlx", "status": "OFFER", "offerPrice": 250000}}	t	2025-09-30 09:38:02.997	cmg0knk3k0005h2br2t8zunlx	cmfqrfvpi0001h27y5vwyur33	2025-09-26 08:20:18.954	2025-09-30 09:38:02.998
cmg6dp9ci0005h2qerwchhob4	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €1,000 on 3 bedroom house	{"property": {"id": "cmfqrfvpi0001h27y5vwyur33", "code": "CAE-2025-0001", "price": "3520000", "title": "3 bedroom house", "address": "fdasfddf"}, "transaction": {"id": "cmg6dp9bl0001h2qejnir8k9j", "status": "OFFER", "offerPrice": 1000}}	f	\N	cmg6dp9bl0001h2qejnir8k9j	cmfqrfvpi0001h27y5vwyur33	2025-09-30 09:52:18.066	2025-09-30 09:52:18.066
cmg6dpp6z0009h2qec9nz3kx5	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Test Seller accepted your offer of €1,000 for 3 bedroom house	{"transaction": {"id": "cmg6dp9bl0001h2qejnir8k9j", "status": "AGREEMENT", "offerPrice": 1000}}	f	\N	cmg6dp9bl0001h2qejnir8k9j	cmfqrfvpi0001h27y5vwyur33	2025-09-30 09:52:38.604	2025-09-30 09:52:38.604
cmg6htwzk000bh2vyrifj8hl5	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €1,500,000 on 2 bedroom	{"property": {"id": "cmfqz0gms0001h2ot3dyehmrb", "code": "CAE-2025-0002", "price": "2501000", "title": "2 bedroom", "address": "adfasd"}, "transaction": {"id": "cmg6htwz80007h2vyigovql8o", "status": "OFFER", "offerPrice": 1500000}}	f	\N	cmg6htwz80007h2vyigovql8o	cmfqz0gms0001h2ot3dyehmrb	2025-09-30 11:47:53.792	2025-09-30 11:47:53.792
cmg6huaoq000fh2vys7tmxi08	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Test Seller accepted your offer of €1,500,000 for 2 bedroom	{"transaction": {"id": "cmg6htwz80007h2vyigovql8o", "status": "AGREEMENT", "offerPrice": 1500000}}	f	\N	cmg6htwz80007h2vyigovql8o	cmfqz0gms0001h2ot3dyehmrb	2025-09-30 11:48:11.546	2025-09-30 11:48:11.546
cmg6j6lpv0003h21lw3fniml3	cmfqptx660003h26llurbau9n	TRANSACTION_STATUS_CHANGE	Payment Proof Uploaded	Buyer uploaded proof of bank transfer. Please review and confirm.	\N	f	\N	cmg6htwz80007h2vyigovql8o	\N	2025-09-30 12:25:45.331	2025-09-30 12:25:45.331
cmg6mydy70005h24smzcb5wuv	cmfqptx660003h26llurbau9n	TRANSACTION_STATUS_CHANGE	Payment Proof Uploaded	Buyer uploaded proof of bank transfer. Please review and confirm.	\N	f	\N	cmg6htwz80007h2vyigovql8o	\N	2025-09-30 14:11:20.479	2025-09-30 14:11:20.479
cmg6nb7c4000hh24sbpailth3	cmfqptx660003h26llurbau9n	NEW_OFFER	New Offer Received	Test Buyer made an offer of €10,000,000 on tatiana 3bedrrom	{"property": {"id": "cmfsabd2q002th2oty827xaik", "code": "CAE-2025-0004", "price": "8500000", "title": "tatiana 3bedrrom", "address": "dsfadfsa"}, "transaction": {"id": "cmg6nb7bt000dh24srvutu1v6", "status": "OFFER", "offerPrice": 10000000}}	f	\N	cmg6nb7bt000dh24srvutu1v6	cmfsabd2q002th2oty827xaik	2025-09-30 14:21:18.437	2025-09-30 14:21:18.437
cmg6nc824000lh24sf71cu9to	cmfqptx630002h26lmvzj0tvd	OFFER_ACCEPTED	Offer Accepted!	Test Seller accepted your offer of €10,000,000 for tatiana 3bedrrom	{"transaction": {"id": "cmg6nb7bt000dh24srvutu1v6", "status": "AGREEMENT", "offerPrice": 10000000}}	f	\N	cmg6nb7bt000dh24srvutu1v6	cmfsabd2q002th2oty827xaik	2025-09-30 14:22:06.028	2025-09-30 14:22:06.028
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.payments (id, "transactionId", type, amount, currency, status, "walletAddress", "txHash", "bankDetails", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.profiles (id, "userId", bio, avatar, "companyName", "taxId", "dateOfBirth", address, "addressLine2", city, "postalCode", country, "termsAcceptedAt", "privacyAcceptedAt", "amlAcceptedAt", "createdAt", "updatedAt") FROM stdin;
cmfqptx350001h26l7ntekibb	cmfqptx350000h26l748hs4s0	Platform Administrator	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-19 10:47:32.033	2025-09-19 10:47:32.033
cmfqzlep4000hh2ot3lkuspvp	cmfqzlep4000gh2otifdq4dj0	\N	\N	\N	\N	1986-05-25 00:00:00	london		london	10614	EE	\N	\N	\N	2025-09-19 15:20:51.112	2025-09-19 15:23:59.802
cmfr17ro5001jh2ottko1s28p	cmfr17ro5001ih2ot5z5v8yu4	\N	\N	\N	\N	1986-02-25 00:00:00	brunos house		lond	12151515	SK	\N	\N	\N	2025-09-19 16:06:13.973	2025-09-19 16:09:39.637
cmfsbmmbq003hh2otdt8nmlsb	cmfsbmmbq003gh2ot62k3rqwr	\N	\N	\N	\N	1960-05-01 00:00:00	Copenhagen lane 1		Copenhagen	1234	DK	\N	\N	\N	2025-09-20 13:45:29.222	2025-09-20 13:48:00.251
cmfzaj4lu0001h2o3kfxbhhaw	cmfzaj4lu0000h2o3cs7zt1h2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-25 10:49:09.907	2025-09-25 10:49:09.907
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.properties (id, code, title, description, address, city, state, "postalCode", country, price, area, bedrooms, bathrooms, "sellerId", "complianceStatus", "complianceNotes", "valuationPrice", "interviewDate", "interviewStatus", "interviewNotes", "finalApprovalStatus", "isVisible", "createdAt", "updatedAt", diagrams, photos, "propertyType") FROM stdin;
cmfz3ysh40001h2fydwpzf4ta	CAE-2025-0005	Carlos property	My property\nhttps://caenhebo.com/	loas vegas	lisbon	lisbon	100000	Portugal	350000.000000000000000000000000000000	125	3	2	cmfqptx660003h26llurbau9n	PENDING	\N	\N	\N	NOT_SCHEDULED	\N	PENDING	f	2025-09-25 07:45:23.368	2025-09-25 09:14:03.475	\N	\N	\N
cmfr1wdd0001rh2oty4ros5td	CAE-2025-0003	3 bedroom	traditoina	cadsfdasdf	lisbon	lisonb	100000	Portugal	3500000.000000000000000000000000000000	125	3	2	cmfr17ro5001ih2ot5z5v8yu4	APPROVED	\N	\N	2025-12-12 08:55:00	COMPLETED	I dont like him, he is from REMAX!	APPROVED	f	2025-09-19 16:25:21.829	2025-09-25 09:14:18.478	\N	\N	\N
cmfsabd2q002th2oty827xaik	CAE-2025-0004	tatiana 3bedrrom	hello	dsfadfsa	lisbon	lisbon	10000	Portugal	8500000.000000000000000000000000000000	252	5	4	cmfqptx660003h26llurbau9n	APPROVED	\N	\N	2055-02-25 08:22:00	COMPLETED	\N	APPROVED	t	2025-09-20 13:08:44.403	2025-09-25 09:14:18.484	\N	\N	\N
cmg0jyt650001h2brcbbus17k	CAE-2025-0006	bruno	bruno property	fdasfasdf	lisbon	lisbon	100000	Portugal	1000.000000000000000000000000000000	125	3	2	cmfr17ro5001ih2ot5z5v8yu4	PENDING	\N	\N	\N	NOT_SCHEDULED	\N	PENDING	f	2025-09-26 08:01:04.301	2025-09-26 08:01:04.301	\N	\N	\N
cmfqrfvpi0001h27y5vwyur33	CAE-2025-0001	3 bedroom house	my house	fdasfddf	lisbon	PUBLISHED	10000	Portugal	3520000.000000000000000000000000000000	25	3	2	cmfqptx660003h26llurbau9n	APPROVED	\N	\N	2026-05-22 08:00:00	COMPLETED	great inverview	APPROVED	t	2025-09-19 11:32:36.295	2025-09-25 09:14:18.484	\N	\N	\N
cmfqz0gms0001h2ot3dyehmrb	CAE-2025-0002	2 bedroom	tatiana walking	adfasd	lisbon	PUBLISHED	10000	Portugal	2501000.000000000000000000000000000000	2243	3	5	cmfqptx660003h26llurbau9n	APPROVED	tatiana likes it	\N	2025-10-22 02:00:00	COMPLETED	nice	APPROVED	t	2025-09-19 15:04:33.844	2025-09-25 09:14:18.484	\N	\N	\N
\.


--
-- Data for Name: property_audits; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.property_audits (id, "propertyId", "adminId", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: property_interests; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.property_interests (id, "propertyId", "buyerId", "interestedAt", message) FROM stdin;
cmfr2okd50029h2otqwaqb119	cmfr1wdd0001rh2oty4ros5td	cmfqptx630002h26lmvzj0tvd	2025-09-19 16:47:17.274	\N
\.


--
-- Data for Name: transaction_status_history; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.transaction_status_history (id, "transactionId", "fromStatus", "toStatus", "changedBy", notes, "createdAt") FROM stdin;
cmg6dp9bp0003h2qekuh1htl5	cmg6dp9bl0001h2qejnir8k9j	\N	OFFER	cmfqptx630002h26lmvzj0tvd	Initial offer created	2025-09-30 09:52:18.037
cmg6dpp6y0007h2qewc0aqx18	cmg6dp9bl0001h2qejnir8k9j	OFFER	AGREEMENT	cmfqptx660003h26llurbau9n	Seller accepted the offer	2025-09-30 09:52:38.602
cmg6dpz66000bh2qed5bui5ny	cmg6dp9bl0001h2qejnir8k9j	AGREEMENT	AGREEMENT	cmfqptx660003h26llurbau9n	Seller signed the Promissory Purchase & Sale Agreement	2025-09-30 09:52:51.535
cmg6dqfsh000dh2qedy54a61v	cmg6dp9bl0001h2qejnir8k9j	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Buyer signed the Promissory Purchase & Sale Agreement	2025-09-30 09:53:13.073
cmg6dqfsk000fh2qe9ej10m5y	cmg6dp9bl0001h2qejnir8k9j	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Both parties have signed the Promissory Purchase & Sale Agreement - Agreement is now fully executed	2025-09-30 09:53:13.076
cmg6dqfsn000hh2qecl6b8m17	cmg6dp9bl0001h2qejnir8k9j	AGREEMENT	FUND_PROTECTION	cmfqptx630002h26lmvzj0tvd	Auto-advanced to Fund Protection after both signatures	2025-09-30 09:53:13.079
cmg6htwzb0009h2vyuubxban5	cmg6htwz80007h2vyigovql8o	\N	OFFER	cmfqptx630002h26lmvzj0tvd	Initial offer created	2025-09-30 11:47:53.784
cmg6huaoo000dh2vyhzrhn2x9	cmg6htwz80007h2vyigovql8o	OFFER	AGREEMENT	cmfqptx660003h26llurbau9n	Seller accepted the offer	2025-09-30 11:48:11.545
cmg6huiau000hh2vybypxl8g6	cmg6htwz80007h2vyigovql8o	AGREEMENT	AGREEMENT	cmfqptx660003h26llurbau9n	Seller signed the Promissory Purchase & Sale Agreement	2025-09-30 11:48:21.415
cmg6hv2ja000jh2vyw89lv0fa	cmg6htwz80007h2vyigovql8o	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Buyer signed the Promissory Purchase & Sale Agreement	2025-09-30 11:48:47.639
cmg6hv2je000lh2vyytss73sf	cmg6htwz80007h2vyigovql8o	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Both parties have signed the Promissory Purchase & Sale Agreement - Agreement is now fully executed	2025-09-30 11:48:47.642
cmg6hv2jg000nh2vy7iwj42g0	cmg6htwz80007h2vyigovql8o	AGREEMENT	FUND_PROTECTION	cmfqptx630002h26lmvzj0tvd	Auto-advanced to Fund Protection after both signatures	2025-09-30 11:48:47.644
cmg6ibthi0001h272mybgvafs	cmg6htwz80007h2vyigovql8o	AGREEMENT	FUND_PROTECTION	cmfqptx660003h26llurbau9n	Advanced by undefined undefined	2025-09-30 12:01:49.063
cmg6mu9o20001h24sbwwiyov2	cmg6htwz80007h2vyigovql8o	AGREEMENT	FUND_PROTECTION	cmfqptx660003h26llurbau9n	Advanced by undefined undefined	2025-09-30 14:08:08.306
cmg6n3o280007h24sqs5ht82a	cmg6htwz80007h2vyigovql8o	FUND_PROTECTION	CLOSING	cmfqptx660003h26llurbau9n	Fiat payment confirmed - all fund protection complete	2025-09-30 14:15:26.864
cmg6n8zzh000bh24sizhj7fqh	cmg6dp9bl0001h2qejnir8k9j	AGREEMENT	FUND_PROTECTION	cmfqptx660003h26llurbau9n	Advanced by undefined undefined	2025-09-30 14:19:35.598
cmg6nb7bw000fh24sn8z5rzp2	cmg6nb7bt000dh24srvutu1v6	\N	OFFER	cmfqptx630002h26lmvzj0tvd	Initial offer created	2025-09-30 14:21:18.428
cmg6nc822000jh24s4txef88z	cmg6nb7bt000dh24srvutu1v6	OFFER	AGREEMENT	cmfqptx660003h26llurbau9n	Seller accepted the offer	2025-09-30 14:22:06.027
cmg6ncjut000nh24shmmquj5y	cmg6nb7bt000dh24srvutu1v6	AGREEMENT	AGREEMENT	cmfqptx660003h26llurbau9n	Seller signed the Promissory Purchase & Sale Agreement	2025-09-30 14:22:21.317
cmg6nd1p5000ph24s5z7fj09h	cmg6nb7bt000dh24srvutu1v6	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Buyer signed the Promissory Purchase & Sale Agreement	2025-09-30 14:22:44.441
cmg6nd1p7000rh24s50z68dd8	cmg6nb7bt000dh24srvutu1v6	AGREEMENT	AGREEMENT	cmfqptx630002h26lmvzj0tvd	Both parties have signed the Promissory Purchase & Sale Agreement - Agreement is now fully executed	2025-09-30 14:22:44.444
cmg6nd1pc000th24sqjofwkj3	cmg6nb7bt000dh24srvutu1v6	AGREEMENT	FUND_PROTECTION	cmfqptx630002h26lmvzj0tvd	Auto-advanced to Fund Protection after both signatures	2025-09-30 14:22:44.448
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.transactions (id, "buyerId", "sellerId", "propertyId", status, "offerPrice", "agreedPrice", "initialPayment", "advancePaymentPercentage", "paymentMethod", "cryptoPercentage", "fiatPercentage", "offerMessage", "offerTerms", "proposalDate", "acceptanceDate", "escrowDate", "completionDate", "deadlineDate", "buyerHasRep", "sellerHasRep", "mediationSigned", "purchaseAgreementSigned", "createdAt", "updatedAt", "buyerSignedPromissory", "buyerSignedPromissoryAt", "purchaseAgreementSignedAt", "sellerSignedPromissory", "sellerSignedPromissoryAt", "buyerSignedMediation", "buyerSignedMediationAt", "sellerSignedMediation", "sellerSignedMediationAt", "buyerKyc2Verified", "buyerKyc2VerifiedAt", "sellerKyc2Verified", "sellerKyc2VerifiedAt", "kyc2StartedAt", "fundProtectionDate") FROM stdin;
cmg6nb7bt000dh24srvutu1v6	cmfqptx630002h26lmvzj0tvd	cmfqptx660003h26llurbau9n	cmfsabd2q002th2oty827xaik	AGREEMENT	10000000.000000000000000000000000000000	10000000.000000000000000000000000000000	\N	0	CRYPTO	100	0	\N	\N	2025-09-30 14:21:18.425	2025-09-30 14:22:06.018	\N	\N	\N	f	f	f	t	2025-09-30 14:21:18.425	2025-09-30 14:22:44.445	t	2025-09-30 14:22:44.439	\N	t	2025-09-30 14:22:21.315	f	\N	f	\N	f	\N	f	\N	\N	\N
cmg6htwz80007h2vyigovql8o	cmfqptx630002h26lmvzj0tvd	cmfqptx660003h26llurbau9n	cmfqz0gms0001h2ot3dyehmrb	CLOSING	1500000.000000000000000000000000000000	1500000.000000000000000000000000000000	\N	0	FIAT	\N	\N	\N	\N	2025-09-30 11:47:53.78	2025-09-30 11:48:11.54	\N	\N	\N	f	f	f	t	2025-09-30 11:47:53.781	2025-09-30 14:15:26.86	t	2025-09-30 11:48:47.636	\N	t	2025-09-30 11:48:21.413	f	\N	f	\N	f	\N	f	\N	\N	2025-09-30 14:08:08.299
cmg6dp9bl0001h2qejnir8k9j	cmfqptx630002h26lmvzj0tvd	cmfqptx660003h26llurbau9n	cmfqrfvpi0001h27y5vwyur33	FUND_PROTECTION	1000.000000000000000000000000000000	1000.000000000000000000000000000000	\N	0	HYBRID	50	50	\N	\N	2025-09-30 09:52:18.033	2025-09-30 09:52:38.598	\N	\N	\N	f	f	f	t	2025-09-30 09:52:18.033	2025-09-30 14:19:35.594	t	2025-09-30 09:53:13.071	\N	t	2025-09-30 09:52:51.532	f	\N	f	\N	f	\N	f	\N	\N	2025-09-30 14:19:35.593
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.users (id, email, password, "emailVerified", role, "firstName", "lastName", phone, "phoneNumber", "phoneVerified", "dateOfBirth", "addressLine1", city, state, "postalCode", country, "paymentPreference", "strigaUserId", "kycStatus", "kycSessionId", "kyc2Status", "kyc2SessionId", "kyc2CompletedAt", "mediationAgreementSigned", "mediationAgreementSignedAt", "createdAt", "updatedAt") FROM stdin;
cmfqptx350000h26l748hs4s0	f@pachoman.com	$2b$10$uyzyFVR5/So5zI7oxrbhGuEucyAZnYl88k/EtE3nGxBZpSj.YByiu	\N	ADMIN	Admin	User	+351000000000	\N	f	1980-01-01 00:00:00	Admin Street 1	Lisbon	\N	1000-000	PT	HYBRID	\N	PASSED	\N	PENDING	\N	\N	f	\N	2025-09-19 10:47:32.033	2025-09-19 10:47:32.033
cmfzaj4lu0000h2o3cs7zt1h2	test4@test.com	$2b$12$kzQ1bL2jMc4mk77R40Qt/.a4ubJsn/nG6GgUbihzNqaUHl1s7YSry	\N	BUYER	Pedor	perez	\N	\N	f	\N	\N	\N	\N	\N	Portugal	FIAT	\N	PENDING	\N	PENDING	\N	\N	f	\N	2025-09-25 10:49:09.907	2025-09-25 10:49:09.907
cmfqptx660003h26llurbau9n	seller@test.com	$2b$10$BRarhpBz//7p9zh0UuZSGepmuY/HkC3lczXIcpH/FniNeqX9xqft2	\N	SELLER	Test	Seller	+351900000002	\N	f	1985-01-01 00:00:00	Seller Avenue 1	Faro	\N	8000-000	PT	FIAT	b3d32c24-4c4f-4db2-9873-04eb0987fa37	PASSED	\N	PASSED	\N	\N	t	\N	2025-09-19 10:47:32.142	2025-09-30 08:03:01.681
cmfqzlep4000gh2otifdq4dj0	test1@test.com	$2b$12$9FRjFdPVqjmW.pOj3NBUgeYdIwJF/XAyZT4d/ZWw2ujxRJF8rk1ny	\N	SELLER	tatiana	perez	\N	+351211111111	f	\N	\N	\N	\N	\N	Portugal	FIAT	3b332c30-0db5-4702-8cc7-789cf4cb2dd3	PASSED	_act-sbx-jwt-eyJhbGciOiJub25lIn0.eyJqdGkiOiJfYWN0LXNieC01YzhmODE3OS0zNzM5LTQ2YjktYWM5Ny0wNmY1MGVhOWZmNWYtdjIiLCJ1cmwiOiJodHRwczovL2FwaS5zdW1zdWIuY29tIn0.-v2	PENDING	\N	\N	f	\N	2025-09-19 15:20:51.112	2025-09-30 08:03:03.06
cmfqptx630002h26lmvzj0tvd	buyer@test.com	$2b$10$BRarhpBz//7p9zh0UuZSGepmuY/HkC3lczXIcpH/FniNeqX9xqft2	\N	BUYER	Test	Buyer	+351900000001	\N	f	1990-01-01 00:00:00	Buyer Street 1	Porto	\N	4000-000	PT	FIAT	8d356d73-0905-40c1-900d-59f7a75d55b5	PASSED	\N	PASSED	_act-sbx-jwt-eyJhbGciOiJub25lIn0.eyJqdGkiOiJfYWN0LXNieC1iMzU3NDI2MC04OTBmLTQ3YjgtODIwNi1lY2VkMTQzZDhhOTYtdjIiLCJ1cmwiOiJodHRwczovL2FwaS5zdW1zdWIuY29tIn0.-v2	\N	t	2025-09-25 09:01:29.308	2025-09-19 10:47:32.14	2025-09-30 08:03:04.442
cmfsbmmbq003gh2ot62k3rqwr	elisa@test.com	$2b$12$G00MB.IOIeVEps3A9PaHv.E52nywuusutNvEPm6KbqgPUsiO4O3gS	\N	BUYER	Elisa	Elisa	\N	+37253912338	f	\N	\N	\N	\N	\N	Portugal	FIAT	230a1eb8-9a3b-476d-b8a5-cc9950ab7854	PASSED	_act-sbx-jwt-eyJhbGciOiJub25lIn0.eyJqdGkiOiJfYWN0LXNieC1lMjc4ZjUyYS04MmEyLTQ4M2EtOTYzNC03ZTBiMzQyMWRmNzktdjIiLCJ1cmwiOiJodHRwczovL2FwaS5zdW1zdWIuY29tIn0.-v2	PENDING	\N	\N	f	\N	2025-09-20 13:45:29.222	2025-09-30 08:03:05.818
cmfr17ro5001ih2ot5z5v8yu4	test2@test.com	$2b$12$c94Aq8YmJJyF4BD9H2.guuWL.oiAFqJ0Z/Ogsg6nqQIAjlcFsUAii	2025-09-30 14:30:18.133	SELLER	Bruno	registers	\N	+351927885532	t	\N	\N	\N	\N	\N	Portugal	FIAT	3cd45665-a7b3-4cb1-99b7-f2a944be6fef	PASSED	_act-sbx-jwt-eyJhbGciOiJub25lIn0.eyJqdGkiOiJfYWN0LXNieC03MjM0MGE2Ny0zMDIwLTQwODYtOWY2MS02OGU0MDEzNGFiZTgtdjIiLCJ1cmwiOiJodHRwczovL2FwaS5zdW1zdWIuY29tIn0.-v2	INITIATED	_act-sbx-jwt-eyJhbGciOiJub25lIn0.eyJqdGkiOiJfYWN0LXNieC1jMTRhNTI1Yi1lN2JhLTQwNGEtODAzYS03MTMxNWEwODQxOTMtdjIiLCJ1cmwiOiJodHRwczovL2FwaS5zdW1zdWIuY29tIn0.-v2	\N	f	\N	2025-09-19 16:06:13.973	2025-09-30 14:30:18.134
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.wallets (id, "userId", "strigaWalletId", currency, address, "qrCode", balance, "lastSyncAt", "createdAt", "updatedAt") FROM stdin;
cmg6bm49d0001h2p16d0sulp9	cmfr17ro5001ih2ot5z5v8yu4	f464a907317bfa6839435468cf5de158	BTC	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.273	2025-09-30 08:53:52.273
cmg6bm49f0003h2p1of97xkpj	cmfr17ro5001ih2ot5z5v8yu4	65bd6eb398c8517f74de05d0337e0844	SOL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.275	2025-09-30 08:53:52.275
cmg6bm49r0007h2p1jt8euik3	cmfr17ro5001ih2ot5z5v8yu4	6c23d7970f000c8879a8e725b70d738e	POL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.288	2025-09-30 08:53:52.288
cmg6bm49t0009h2p1ahgcnjho	cmfr17ro5001ih2ot5z5v8yu4	fd06566939cb28d06d4df57807630eef	BNB	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.29	2025-09-30 08:53:52.29
cmg6bm49y000dh2p1irq2f08m	cmfr17ro5001ih2ot5z5v8yu4	19371af4f0decf19fe088f7409e405a4	EUR	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.294	2025-09-30 08:53:52.294
cmg6bm5ol000fh2p1j33kt60v	cmfqptx660003h26llurbau9n	04aaa5628f11a12528452f355764313c	BTC	tb1qzdml3th59rj6eedawatddmapdkygw4xx3we3vf	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.118	2025-09-30 08:53:54.118
cmg6bm5on000hh2p17jpopu8t	cmfqptx660003h26llurbau9n	5c794dcf3319385384d4465f5985b8f8	EUR	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.12	2025-09-30 08:53:54.12
cmg6bm5oy000nh2p15kvas7tc	cmfqptx660003h26llurbau9n	157f8f6bd6646e3205d91700a9699b3a	SOL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.13	2025-09-30 08:53:54.13
cmg6bm5oz000ph2p1ag74q3et	cmfqptx660003h26llurbau9n	53a674187b0f6ce92fe3b2403dd48380	BNB	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.132	2025-09-30 08:53:54.132
cmg6bm5p0000rh2p1p6elx5u0	cmfqptx660003h26llurbau9n	a46618561fffa103fd16ea97755d7dae	POL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.133	2025-09-30 08:53:54.133
cmg6bm6wx000th2p1z0yorp57	cmfqzlep4000gh2otifdq4dj0	71ae5d0a470518a3ee2db2f4bb9dbf96	BTC	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.714	2025-09-30 08:53:55.714
cmg6bm6wz000vh2p1mo4n0euv	cmfqzlep4000gh2otifdq4dj0	952eb62dd8b722da6f15fa6cceb72bb7	EUR	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.715	2025-09-30 08:53:55.715
cmg6bm6x1000zh2p1amhpj03u	cmfqzlep4000gh2otifdq4dj0	9241455215893adbe4b7c9f7e12c1a7d	BNB	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.718	2025-09-30 08:53:55.718
cmg6bm6x40011h2p1thn8sq9y	cmfqzlep4000gh2otifdq4dj0	f04b9072f1ad6460c702f41edf04cf27	POL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.721	2025-09-30 08:53:55.721
cmg6bm6x90015h2p1weaolxr1	cmfqzlep4000gh2otifdq4dj0	ce7ec3968258a9745025edad1d0ea1be	SOL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.726	2025-09-30 08:53:55.726
cmg6bm86g0017h2p1oks5v8er	cmfqptx630002h26lmvzj0tvd	699e064b59ba372c3e645c6b2e4ee601	BNB	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.353	2025-09-30 08:53:57.353
cmg6bm86i0019h2p1l9pz75o1	cmfqptx630002h26lmvzj0tvd	2b798d97a90c7255d1b16c1b73beb0e0	POL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.354	2025-09-30 08:53:57.354
cmg6bm86n001fh2p12hjursp4	cmfqptx630002h26lmvzj0tvd	b3112d98fc921570696dfd9b2d40f225	EUR	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.36	2025-09-30 08:53:57.36
cmg6bm86p001hh2p19ss0vfm2	cmfqptx630002h26lmvzj0tvd	fa9493118c61e3ade592b9967610aded	SOL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.361	2025-09-30 08:53:57.361
cmg6bm9f8001lh2p1utffua3p	cmfsbmmbq003gh2ot62k3rqwr	7c9a8746868bbf9049ca16f59a7f39d9	EUR	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.965	2025-09-30 08:53:58.965
cmg6bm9ff001ph2p1hqh2arx1	cmfsbmmbq003gh2ot62k3rqwr	a0ae2f838ec63978353f13e7bbe72302	SOL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.972	2025-09-30 08:53:58.972
cmg6bm9fh001rh2p1sfzarzn3	cmfsbmmbq003gh2ot62k3rqwr	a0c70ed66a4bf0a1e8f0c981f6557cd7	BTC	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.973	2025-09-30 08:53:58.973
cmg6bm9fi001th2p1blaj9bzp	cmfsbmmbq003gh2ot62k3rqwr	7004f0caaaf4bccc86d2880c095db5c3	POL	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.974	2025-09-30 08:53:58.974
cmg6bm9fj001vh2p1o992n5jz	cmfsbmmbq003gh2ot62k3rqwr	493b64e5f0adcff6bbf0c186a9dbe6b7	BNB	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.976	2025-09-30 08:53:58.976
cmg6bm9fk001xh2p1t2kytkom	cmfsbmmbq003gh2ot62k3rqwr	8ecc3baa7483930c40dfd48b9c68d580	ETH	\N	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.977	2025-09-30 08:53:58.977
cmg6bm86q001jh2p1wh8m98s4	cmfqptx630002h26lmvzj0tvd	aa1a9703000b7c00a5a0dc8015d68fe4	ETH	0xaA654b5ef5D251FF612C0E7C458561c064CBE81c	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.362	2025-09-30 08:53:57.362
cmg6bm5oq000jh2p1iqqgtome	cmfqptx660003h26llurbau9n	bab9cd9f06c56c9f73040cbf1c18de5f	ETH	0x7999937166dAdc7ff01199e378B803FE584Af967	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.122	2025-09-30 08:53:54.122
cmg6bm49m0005h2p1j4ebs8dt	cmfr17ro5001ih2ot5z5v8yu4	8a91bd56463ea93461e43c2f7f914e40	USDC	9iQ3C67fHKpA8D25ACEJzsJXb4mScG8yu22jo8LZgkr	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.282	2025-09-30 11:03:44.15
cmg6bm49u000bh2p1nalx4txi	cmfr17ro5001ih2ot5z5v8yu4	21f0150aabe996829ed672444f568e28	ETH	0x0B210893973159e8728d76D3A8dfc3F52F7623Ce	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:52.291	2025-09-30 11:03:46.618
cmg6bm5ow000lh2p1abxgsc8s	cmfqptx660003h26llurbau9n	3065baf88deb0369103cc3f8c6fb7ddd	USDC	BZNgAD7xLFGiMSStEENp5Ro4Lt9LZr9szuPxRjeKEFcJ	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:54.129	2025-09-30 11:03:51.202
cmg6bm6x0000xh2p16fiv2qbj	cmfqzlep4000gh2otifdq4dj0	36f0177caac71bfb13fd4779d917f471	USDC	CXm9bNrd26g1WJpA1CH8kGgcKJGCd4HbeQWSsPJN4aky	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.716	2025-09-30 11:04:06.807
cmg6bm6x80013h2p1rh14topr	cmfqzlep4000gh2otifdq4dj0	d05967a0d249b2a82db6b628e1867fcc	ETH	0x940EE9158b5Ef5Ac8bcb91f0E41A3d308432439F	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:55.724	2025-09-30 11:04:09.321
cmg6bm86j001bh2p125bmrtmu	cmfqptx630002h26lmvzj0tvd	292b58d0dd7edf25373cba4f8ddd9ba5	USDC	6QoJH63BDnmCKi5HAWCDMhs6Wr3aAY7onjuCCvSWKt9f	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.356	2025-09-30 11:04:14.486
cmg6bm86m001dh2p1zojoh5qt	cmfqptx630002h26lmvzj0tvd	3225bfd1ec6384ddee90e80d01665235	BTC	tb1quhxyn73fsxcskd39nw0u6kxhdchvdqn824cq4p	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:57.358	2025-09-30 11:04:16.905
cmg6bm9fe001nh2p1kdqnlty7	cmfsbmmbq003gh2ot62k3rqwr	cba1db190bf0b1c348599498f4ac629a	USDC	Fo1S2MRCmqWGj46m9QyCe93wh75See2LasuFGkeEZFQH	\N	0.000000000000000000000000000000	\N	2025-09-30 08:53:58.971	2025-09-30 11:04:22.149
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: caenhebo
--

COPY public.webhook_events (id, "eventType", source, "eventId", payload, processed, "processedAt", error, "createdAt") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: counter_offers counter_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.counter_offers
    ADD CONSTRAINT counter_offers_pkey PRIMARY KEY (id);


--
-- Name: digital_ibans digital_ibans_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.digital_ibans
    ADD CONSTRAINT digital_ibans_pkey PRIMARY KEY (id);


--
-- Name: document_access document_access_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT document_access_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: escrow_details escrow_details_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_details
    ADD CONSTRAINT escrow_details_pkey PRIMARY KEY (id);


--
-- Name: fund_protection_steps fund_protection_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.fund_protection_steps
    ADD CONSTRAINT fund_protection_steps_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: legal_templates legal_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.legal_templates
    ADD CONSTRAINT legal_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_audits property_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT property_audits_pkey PRIMARY KEY (id);


--
-- Name: property_interests property_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT property_interests_pkey PRIMARY KEY (id);


--
-- Name: transaction_status_history transaction_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transaction_status_history
    ADD CONSTRAINT transaction_status_history_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts_userId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "bank_accounts_userId_key" ON public.bank_accounts USING btree ("userId");


--
-- Name: digital_ibans_iban_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX digital_ibans_iban_key ON public.digital_ibans USING btree (iban);


--
-- Name: document_access_propertyId_buyerId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "document_access_propertyId_buyerId_key" ON public.document_access USING btree ("propertyId", "buyerId");


--
-- Name: escrow_details_transactionId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "escrow_details_transactionId_key" ON public.escrow_details USING btree ("transactionId");


--
-- Name: fund_protection_steps_transactionId_stepNumber_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "fund_protection_steps_transactionId_stepNumber_key" ON public.fund_protection_steps USING btree ("transactionId", "stepNumber");


--
-- Name: profiles_userId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "profiles_userId_key" ON public.profiles USING btree ("userId");


--
-- Name: properties_code_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX properties_code_key ON public.properties USING btree (code);


--
-- Name: property_interests_propertyId_buyerId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "property_interests_propertyId_buyerId_key" ON public.property_interests USING btree ("propertyId", "buyerId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_strigaUserId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "users_strigaUserId_key" ON public.users USING btree ("strigaUserId");


--
-- Name: wallets_strigaWalletId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "wallets_strigaWalletId_key" ON public.wallets USING btree ("strigaWalletId");


--
-- Name: wallets_userId_currency_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "wallets_userId_currency_key" ON public.wallets USING btree ("userId", currency);


--
-- Name: webhook_events_source_eventId_key; Type: INDEX; Schema: public; Owner: caenhebo
--

CREATE UNIQUE INDEX "webhook_events_source_eventId_key" ON public.webhook_events USING btree (source, "eventId");


--
-- Name: bank_accounts bank_accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT "bank_accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: counter_offers counter_offers_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.counter_offers
    ADD CONSTRAINT "counter_offers_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: digital_ibans digital_ibans_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.digital_ibans
    ADD CONSTRAINT "digital_ibans_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_grantedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_grantedBy_fkey" FOREIGN KEY ("grantedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_access document_access_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.document_access
    ADD CONSTRAINT "document_access_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_adminReviewedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_adminReviewedBy_fkey" FOREIGN KEY ("adminReviewedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: escrow_details escrow_details_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.escrow_details
    ADD CONSTRAINT "escrow_details_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fund_protection_steps fund_protection_steps_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.fund_protection_steps
    ADD CONSTRAINT "fund_protection_steps_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interviews interviews_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profiles profiles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: properties properties_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT "properties_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: property_audits property_audits_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT "property_audits_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: property_audits property_audits_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_audits
    ADD CONSTRAINT "property_audits_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_interests property_interests_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT "property_interests_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_interests property_interests_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.property_interests
    ADD CONSTRAINT "property_interests_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaction_status_history transaction_status_history_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transaction_status_history
    ADD CONSTRAINT "transaction_status_history_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public.transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions transactions_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions transactions_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: wallets wallets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caenhebo
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT "wallets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict X5UH91oozuzbD6a4vDk5BEqm7vOu82xVSk2JkJKMeGOa5SyKm6qtFAmdYrEWcJN

